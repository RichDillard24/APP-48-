console.log('script')

function temp(){

    const celsius=prompt("Enter Celsius value");

    const fahrenheit=(celsius * 9/5) + 32

    document.getElementById("templist").innerHTML+=`
    <li> ${celsius} The conversion of Celcius ${fahrenheit} to Fahrenheit is </li>`;
}